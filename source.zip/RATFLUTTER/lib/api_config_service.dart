import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiConfigService {
  static final ApiConfigService _instance = ApiConfigService._internal();
  factory ApiConfigService() => _instance;
  ApiConfigService._internal();

  /// RAW GIST CONFIG URL
  static const String _gistConfigUrl =
      'https://gist.githubusercontent.com/lemvengs-wq/5d3cf71b642c810797b8eedc22093451/raw/config.json';

  /// REQUEST HEADERS
  static const Map<String, String> _requestHeaders = {
    'User-Agent': 'Paradise-App/1.0',
    'Accept': 'application/json',
    'Cache-Control': 'no-cache',
  };

  /// CACHE KEYS
  static const String _prefKeyBaseUrl = 'cached_base_url';
  static const String _prefKeyLastUpdate = 'last_update_timestamp';

  /// MEMORY CACHE
  String? _cachedBaseUrl;

  /// LOADING FLAG (biar gak double request)
  bool _isLoading = false;

  /// GET BASE URL (cache -> prefs -> fetch)
  Future<String> getBaseUrl() async {
    // Memory cache
    if (_cachedBaseUrl != null && _cachedBaseUrl!.isNotEmpty) {
      return _cachedBaseUrl!;
    }

    // SharedPreferences cache
    final prefs = await SharedPreferences.getInstance();
    final cachedUrl = prefs.getString(_prefKeyBaseUrl);

    if (cachedUrl != null && cachedUrl.isNotEmpty) {
      _cachedBaseUrl = cachedUrl;

      // Background update (tidak ganggu user)
      _fetchAndUpdateInBackground();

      return cachedUrl;
    }

    // Kalau tidak ada cache sama sekali
    return await fetchBaseUrl();
  }

  /// FORCE FETCH FROM GIST
  Future<String> fetchBaseUrl() async {
    // Kalau lagi loading, tunggu sampai selesai
    if (_isLoading) {
      while (_isLoading) {
        await Future.delayed(const Duration(milliseconds: 100));
      }

      if (_cachedBaseUrl != null && _cachedBaseUrl!.isNotEmpty) {
        return _cachedBaseUrl!;
      }

      throw Exception("Config masih kosong setelah loading");
    }

    _isLoading = true;

    try {
      print('🌐 Fetching config from Gist...');

      final response = await http
          .get(Uri.parse(_gistConfigUrl), headers: _requestHeaders)
          .timeout(const Duration(seconds: 15));

      if (response.statusCode != 200) {
        throw Exception('HTTP ${response.statusCode}');
      }

      final jsonData = jsonDecode(response.body);

      // Ambil url_aktif dari JSON
      final activeUrl = jsonData['url_aktif']?.toString().trim();

      if (activeUrl == null || activeUrl.isEmpty) {
        throw Exception('Field "url_aktif" kosong / tidak ada');
      }

      print('✅ Base URL: $activeUrl');

      // Simpan cache
      await _saveToCache(activeUrl);

      // Simpan memory cache
      _cachedBaseUrl = activeUrl;

      return activeUrl;
    } catch (e) {
      print('❌ Error fetchBaseUrl: $e');

      // fallback ke cache prefs kalau ada
      final cachedUrl = await _getCachedUrl();
      if (cachedUrl != null && cachedUrl.isNotEmpty) {
        print('📦 Pakai cache: $cachedUrl');
        _cachedBaseUrl = cachedUrl;
        return cachedUrl;
      }

      throw Exception('Gagal ambil config & tidak ada cache: $e');
    } finally {
      _isLoading = false;
    }
  }

  /// UPDATE CONFIG IN BACKGROUND (silent)
  Future<void> _fetchAndUpdateInBackground() async {
    try {
      final response = await http
          .get(Uri.parse(_gistConfigUrl), headers: _requestHeaders)
          .timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) return;

      final jsonData = jsonDecode(response.body);

      final activeUrl = jsonData['url_aktif']?.toString().trim();

      if (activeUrl == null || activeUrl.isEmpty) return;

      await _saveToCache(activeUrl);
      _cachedBaseUrl = activeUrl;

      print('🔄 Updated (background): $activeUrl');
    } catch (_) {}
  }

  /// SAVE TO PREFS
  Future<void> _saveToCache(String url) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefKeyBaseUrl, url);
    await prefs.setInt(_prefKeyLastUpdate, DateTime.now().millisecondsSinceEpoch);
  }

  /// GET CACHED URL FROM PREFS
  Future<String?> _getCachedUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_prefKeyBaseUrl);
  }

  /// FORCE REFRESH (hapus memory cache)
  Future<String> forceRefresh() async {
    _cachedBaseUrl = null;
    return await fetchBaseUrl();
  }

  /// CLEAR ALL CACHE
  Future<void> clearCache() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_prefKeyBaseUrl);
    await prefs.remove(_prefKeyLastUpdate);
    _cachedBaseUrl = null;
  }

  /// GET LAST UPDATE TIME
  Future<DateTime?> getLastUpdateTime() async {
    final prefs = await SharedPreferences.getInstance();
    final timestamp = prefs.getInt(_prefKeyLastUpdate);

    if (timestamp != null) {
      return DateTime.fromMillisecondsSinceEpoch(timestamp);
    }
    return null;
  }

  /// CHECK IF SHOULD UPDATE
  Future<bool> shouldUpdate() async {
    final lastUpdate = await getLastUpdateTime();
    if (lastUpdate == null) return true;

    final diff = DateTime.now().difference(lastUpdate);
    return diff.inHours >= 1;
  }
}

/// SIMPLE GLOBAL ACCESS
class ApiConfig {
  static final ApiConfigService _service = ApiConfigService();

  static Future<String> get baseUrl async => await _service.getBaseUrl();

  static Future<String> refresh() async => await _service.forceRefresh();

  static Future<void> clearCache() async => await _service.clearCache();
}